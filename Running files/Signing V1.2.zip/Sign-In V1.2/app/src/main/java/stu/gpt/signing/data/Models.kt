package stu.gpt.signing.data

import androidx.compose.ui.graphics.Color
import java.time.Instant

// App configurable settings
data class AppSettings(
    val pin: String = "2025",
    val headerText: String = "",
    val themeOption: ThemeOption = ThemeOption.OPTION1,
    val historyRetentionDays: Long = 90,
    val isScreenFlipped: Boolean = false,
    val dailyJobEnabled: Boolean = true,
    // Daily auto refresh time (24h clock). Previously fixed at 03:00.
    val dailyJobHour: Int = 3,
    val dailyJobMinute: Int = 0,
    // UI Headings
    val leftHeading: String = "Visitors Or Support Crew",
    val rightHeading: String = "Cast Members",
    // Persisted last-picked document URIs (as strings) for auto refresh
    val namesUriString: String? = null,
    val rolesUriString: String? = null,
    val locationsUriString: String? = null,
    val regularListUriString: String? = null,
    // Last uploaded Regular List header (row 1, col 1) to detect changes
    val lastRegularListHeader: String? = null,
    // One-time flag: after special reset (######), next auto refresh conditionally reloads Cast
    val conditionalRegularListReloadPending: Boolean = false,
) {
    val primaryBgColor: Color get() = when (themeOption) {
        ThemeOption.OPTION1 -> Color(0xFF9BC2E6)
        ThemeOption.OPTION2 -> Color(0xFFC6E0B4)
        ThemeOption.OPTION3 -> Color(0xFFE1EDEF)
    }
    val primaryTextColor: Color = Color(0xFF000000)
}

enum class ThemeOption { OPTION1, OPTION2, OPTION3 }

// Domain models

data class VisitorEntry(
    val name: String,
    val roleOrLocation: String,
    val arrivalEpochMillis: Long = Instant.now().toEpochMilli(),
)

data class HistoryEntry(
    val name: String,
    val roleOrLocation: String,
    val arrivalEpochMillis: Long,
    val departureEpochMillis: Long = Instant.now().toEpochMilli(),
)
