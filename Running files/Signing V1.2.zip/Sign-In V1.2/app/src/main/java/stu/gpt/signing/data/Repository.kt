package stu.gpt.signing.data

import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.content.ContentValues
import java.io.File
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object Repository {
    private lateinit var appContext: Context
    private const val PREFS_NAME = "signing_prefs"
    private const val KEY_PIN = "pin"
    private const val KEY_HEADER = "headerText"
    private const val KEY_THEME = "themeOption"
    private const val KEY_RETENTION = "historyRetentionDays"
    private const val KEY_FLIPPED = "isScreenFlipped"
    private const val KEY_DAILY_ENABLED = "dailyJobEnabled"
    private const val KEY_DAILY_HOUR = "dailyJobHour"
    private const val KEY_DAILY_MINUTE = "dailyJobMinute"
    private const val KEY_LEFT_HEADING = "leftHeading"
    private const val KEY_RIGHT_HEADING = "rightHeading"
    private const val KEY_URI_NAMES = "namesUriString"
    private const val KEY_URI_ROLES = "rolesUriString"
    private const val KEY_URI_LOCATIONS = "locationsUriString"
    private const val KEY_URI_REGULAR_LIST = "regularListUriString"
    private const val KEY_LAST_REGULAR_LIST_HEADER = "lastRegularListHeader"
    private const val KEY_CONDITIONAL_REGULAR_LIST_RELOAD_PENDING = "conditionalRegularListReloadPending"

    // Settings (in-memory for now; can be persisted with DataStore later)
    var settings by mutableStateOf(AppSettings())
        private set

    // Runtime play title obtained from Regular List (first row, column 1). Not persisted.
    var playTitle by mutableStateOf("")

    // Data sources (in-memory for now)
    val names = mutableStateListOf<String>()
    val roles = mutableStateListOf<String>()
    val locations = mutableStateListOf<String>()
    // RegularList members (formerly Stage)
    val stageMembers = mutableStateListOf<String>()
    // Map of member name -> tapped time (epoch millis) for highlighting and sorting
    val stageTappedAt = androidx.compose.runtime.mutableStateMapOf<String, Long>()
    // Map of member name -> active sign-in (arrival epoch millis)
    val stageActive = androidx.compose.runtime.mutableStateMapOf<String, Long>()

    // RegularList aliases for consistency (map to Stage-backed data)
    val regularListMembers: List<String> get() = stageMembers
    val regularListTappedAt: Map<String, Long> get() = stageTappedAt
    val regularListActive: Map<String, Long> get() = stageActive

    val visitors = mutableStateListOf<VisitorEntry>()
    val history = mutableStateListOf<HistoryEntry>()

    /**
     * Must be called once from application (e.g., MainActivity.onCreate).
     * Loads persisted history, prunes entries older than 90 days, and saves back.
     */
    fun initialize(context: Context) {
        appContext = context.applicationContext
        // Ensure default data folder exists under public Downloads
        ensureDefaultDataFolder()
        // Load settings from SharedPreferences
        loadSettings()
        // Restore uploaded files (Names, Lists, Regular List) from persisted URIs on app startup
        refreshAllFromPersistedUris()
        // Load any prior history from disk
        val loaded = Storage.loadHistory(appContext)
        history.clear(); history.addAll(loaded)
        // Enforce retention at startup based on current settings
        pruneHistoryOlderThan(days = settings.historyRetentionDays)
        saveHistory()
        // Load previously active visitors
        runCatching { Storage.loadVisitors(appContext) }.getOrNull()?.let { prevVisitors ->
            visitors.clear(); visitors.addAll(prevVisitors)
            resortVisitors()
        }
        // Load persisted RegularList members list so it survives accidental closure
        runCatching { Storage.loadRegularListMembers(appContext) }.getOrNull()?.let { members ->
            if (members.isNotEmpty()) {
                stageMembers.clear(); stageMembers.addAll(members)
            }
        }
        // Ensure daily maintenance is scheduled
        scheduleDailyMaintenance(appContext)

        // Cleanup legacy Stage files if migration to RegularList has taken place
        Storage.removeLegacyStageFilesIfMigrated(appContext)
    }

    /**
     * Ensures a user-visible default folder exists for storing CSV databases:
     * Documents/Sign-In Data
     * Best-effort; ignores failures on devices with scoped storage.
     */
    private fun ensureDefaultDataFolder() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+: Use MediaStore Files under Documents/Sign-In Data
                val resolver = appContext.contentResolver
                val relativePath = Environment.DIRECTORY_DOCUMENTS + "/Sign-In Data/"
                val contentUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                // Check if a keep file already exists (.keep or _.keep); if so, skip creation
                val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME} IN (?, ?)"
                val args = arrayOf(relativePath, ".keep", "_.keep")
                resolver.query(contentUri, arrayOf(MediaStore.MediaColumns._ID), selection, args, null)?.use { c ->
                    if (c.moveToFirst()) return
                }
                // Insert placeholder file (choose '_.keep') to ensure folder appears
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "_.keep")
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
                resolver.insert(contentUri, values)?.let { uri ->
                    resolver.openOutputStream(uri)?.use { /* create empty file */ }
                }
            } else {
                // Legacy approach for pre-Android 10: create under public Documents
                val documents = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                val target = File(documents, "Sign-In Data")
                if (!target.exists()) {
                    target.mkdirs()
                    // Create an empty '_.keep' file to mark the folder
                    runCatching {
                        val keep = File(target, "_.keep")
                        if (!keep.exists()) keep.writeBytes(ByteArray(0))
                    }
                } else {
                    // If folder exists, do not add another keep file
                    return
                }
            }
        }
    }

    fun updateSettings(update: (AppSettings) -> AppSettings) {
        settings = update(settings)
        saveSettings()
    }

    fun signIn(name: String, roleOrLocation: String) {
        val trimmedName = name.trim().ifEmpty { return }
        val col = roleOrLocation.trim()
        val existsInDb = names.any { it.equals(trimmedName, ignoreCase = true) }
        val finalName = if (existsInDb) trimmedName else "$trimmedName (Guest)"
        visitors.add(VisitorEntry(finalName, col, Instant.now().toEpochMilli()))
        resortVisitors()
        if (::appContext.isInitialized) Storage.saveVisitors(appContext, visitors)
    }

    private fun resortVisitors() {
        // Role entries first, then alphabetical by name (case-insensitive). If role vs location is unknown, treat as location.
        val sorted = visitors.sortedWith(compareBy(
            { e ->
                val isRole = roles.any { it.equals(e.roleOrLocation, ignoreCase = true) }
                if (isRole) 0 else 1
            },
            { e -> e.name.lowercase() },
            { e -> e.roleOrLocation.lowercase() }
        ))
        visitors.clear(); visitors.addAll(sorted)
    }

    fun signOut(entry: VisitorEntry) {
        visitors.remove(entry)
        history.add(
            HistoryEntry(
                name = entry.name,
                roleOrLocation = entry.roleOrLocation,
                arrivalEpochMillis = entry.arrivalEpochMillis,
                departureEpochMillis = Instant.now().toEpochMilli()
            )
        )
        // Enforce retention and persist
        pruneHistoryOlderThan(days = settings.historyRetentionDays)
        saveHistory()
        if (::appContext.isInitialized) Storage.saveVisitors(appContext, visitors)
    }

    /**
     * Sign-out all currently signed-in Visitors immediately and move them to history.
     */
    fun signOutAllNow() {
        if (visitors.isEmpty()) return
        val now = Instant.now().toEpochMilli()
        val toArchive = visitors.map { v ->
            HistoryEntry(
                name = v.name,
                roleOrLocation = v.roleOrLocation,
                arrivalEpochMillis = v.arrivalEpochMillis,
                departureEpochMillis = now
            )
        }
        visitors.clear()
        history.addAll(toArchive)
        pruneHistoryOlderThan(days = settings.historyRetentionDays)
        saveHistory()
        if (::appContext.isInitialized) Storage.saveVisitors(appContext, visitors)
    }

    fun loadNames(items: List<String>) { names.clear(); names.addAll(items.filter { it.isNotBlank() }.distinct()) }
    fun loadRoles(items: List<String>) { roles.clear(); roles.addAll(items.filter { it.isNotBlank() }.distinct()) }
    fun loadLocations(items: List<String>) { locations.clear(); locations.addAll(items.filter { it.isNotBlank() }.distinct()) }
    fun loadRegularListMembers(items: List<String>) {
        val clean = items.filter { it.isNotBlank() }.distinct()
        stageMembers.clear(); stageMembers.addAll(clean)
        // Reset tapped state on new upload so all appear as untapped (red-highlighted)
        stageTappedAt.clear()
        // Clear any active RegularList sign-ins when a fresh list is uploaded
        stageActive.clear()
        if (::appContext.isInitialized) {
            Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
            Storage.saveRegularListMembers(appContext, stageMembers)
        }
    }

    /**
     * Replace Stage members list while preserving current active/tapped state for members that remain.
     * Any active/tapped entries for names no longer present are removed. No history entries are created here.
     */
    fun replaceRegularListMembersPreserveState(newItems: List<String>) {
        val clean = newItems.filter { it.isNotBlank() }.distinct()
        // Remove state for names that no longer exist
        val toRemoveActive = stageActive.keys - clean.toSet()
        toRemoveActive.forEach { stageActive.remove(it) }
        val toRemoveTapped = stageTappedAt.keys - clean.toSet()
        toRemoveTapped.forEach { stageTappedAt.remove(it) }
        // Update the list
        stageMembers.clear(); stageMembers.addAll(clean)
        if (::appContext.isInitialized) {
            Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
            Storage.saveRegularListMembers(appContext, stageMembers)
        }
    }

    /**
     * Toggle a Stage member's sign-in state.
     * - If currently not signed in: record Sign-In time and highlight green.
     * - If currently signed in: record Sign-Out time, add to history for export, and revert to red.
     */
    fun regularListToggle(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val now = Instant.now().toEpochMilli()
        val current = stageActive[trimmed]
        if (current == null) {
            // Sign-In
            stageActive[trimmed] = now
            stageTappedAt[trimmed] = now
        } else {
            // Sign-Out -> move to history and clear highlight
            stageActive.remove(trimmed)
            stageTappedAt.remove(trimmed)
            history.add(
                HistoryEntry(
                    name = trimmed,
                    roleOrLocation = "RegularList",
                    arrivalEpochMillis = current,
                    departureEpochMillis = now
                )
            )
            // Enforce retention and persist
            pruneHistoryOlderThan(days = settings.historyRetentionDays)
            saveHistory()
        }
        if (::appContext.isInitialized) Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
    }

    /**
     * Force sign-out all active Stage members, sending them to history and clearing highlights.
     */
    fun regularListSignOutAllNow() {
        if (stageActive.isEmpty()) return
        val now = Instant.now().toEpochMilli()
        val toArchive = stageActive.map { (name, start) ->
            HistoryEntry(
                name = name,
                roleOrLocation = "RegularList",
                arrivalEpochMillis = start,
                departureEpochMillis = now
            )
        }
        stageActive.clear()
        stageTappedAt.clear()
        history.addAll(toArchive)
        pruneHistoryOlderThan(days = settings.historyRetentionDays)
        saveHistory()
        if (::appContext.isInitialized) Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
    }

    /**
     * Clear the entire Cast (Stage members) list and any active/tapped state,
     * then reset the title to "Visitor Sign-In". All changes are persisted so
     * they survive accidental app closure.
     */
    fun clearRegularListAndResetTitle() {
        stageMembers.clear()
        stageActive.clear()
        stageTappedAt.clear()
        if (::appContext.isInitialized) {
            Storage.saveRegularListMembers(appContext, stageMembers)
            Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
        }
        updateSettings { it.copy(headerText = "Visitor Sign-In") }
    }

    fun exportHistoryCsv(): Boolean {
        // Export is handled via SAF in the UI where a Uri is provided.
        // Keeping stub to avoid breaking callers; returns false to indicate no-op.
        return false
    }

    fun clearVisitorsOlderThan(days: Long) {
        val cutoff = Instant.now().minusSeconds(days * 24 * 3600).toEpochMilli()
        visitors.removeAll { it.arrivalEpochMillis < cutoff }
    }

    fun clearVisitorsOnExport() {
        visitors.clear()
    }

    private fun pruneHistoryOlderThan(days: Long) {
        val cutoff = Instant.now().minusSeconds(days * 24 * 3600).toEpochMilli()
        history.removeAll { it.departureEpochMillis < cutoff }
    }

    private fun saveHistory() {
        if (::appContext.isInitialized) {
            Storage.saveHistory(appContext, history)
        }
    }

    private fun loadSettings() {
        if (!::appContext.isInitialized) return
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val themeName = prefs.getString(KEY_THEME, ThemeOption.OPTION1.name) ?: ThemeOption.OPTION1.name
        // Legacy migration: if previous 'stageUriString' exists, use it as regularListUriString when new key is absent
        val legacyStageUri = prefs.getString("stageUriString", null)
        val mergedRegularListUri = prefs.getString(KEY_URI_REGULAR_LIST, null) ?: legacyStageUri
        val loaded = AppSettings(
            pin = prefs.getString(KEY_PIN, "2025") ?: "2025",
            headerText = prefs.getString(KEY_HEADER, "") ?: "",
            themeOption = runCatching { ThemeOption.valueOf(themeName) }.getOrDefault(ThemeOption.OPTION1),
            historyRetentionDays = prefs.getLong(KEY_RETENTION, 90L),
            isScreenFlipped = prefs.getBoolean(KEY_FLIPPED, false),
            dailyJobEnabled = prefs.getBoolean(KEY_DAILY_ENABLED, true),
            dailyJobHour = prefs.getInt(KEY_DAILY_HOUR, 3),
            dailyJobMinute = prefs.getInt(KEY_DAILY_MINUTE, 0),
            leftHeading = (prefs.getString(KEY_LEFT_HEADING, null) ?: AppSettings().leftHeading).take(30),
            rightHeading = (prefs.getString(KEY_RIGHT_HEADING, null) ?: AppSettings().rightHeading).take(15),
            namesUriString = prefs.getString(KEY_URI_NAMES, null),
            rolesUriString = prefs.getString(KEY_URI_ROLES, null),
            locationsUriString = prefs.getString(KEY_URI_LOCATIONS, null),
            regularListUriString = mergedRegularListUri,
            lastRegularListHeader = prefs.getString(KEY_LAST_REGULAR_LIST_HEADER, null),
            conditionalRegularListReloadPending = prefs.getBoolean(KEY_CONDITIONAL_REGULAR_LIST_RELOAD_PENDING, false)
        )
        settings = loaded
        // Persist migrated value if we used the legacy key
        if (legacyStageUri != null && prefs.getString(KEY_URI_REGULAR_LIST, null) == null) {
            prefs.edit().putString(KEY_URI_REGULAR_LIST, legacyStageUri).apply()
        }
    }

    private fun saveSettings() {
        if (!::appContext.isInitialized) return
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_PIN, settings.pin)
            .putString(KEY_HEADER, settings.headerText)
            .putString(KEY_THEME, settings.themeOption.name)
            .putLong(KEY_RETENTION, settings.historyRetentionDays)
            .putBoolean(KEY_FLIPPED, settings.isScreenFlipped)
            .putBoolean(KEY_DAILY_ENABLED, settings.dailyJobEnabled)
            .putInt(KEY_DAILY_HOUR, settings.dailyJobHour)
            .putInt(KEY_DAILY_MINUTE, settings.dailyJobMinute)
            .putString(KEY_LEFT_HEADING, settings.leftHeading.take(30))
            .putString(KEY_RIGHT_HEADING, settings.rightHeading.take(15))
            .putString(KEY_URI_NAMES, settings.namesUriString)
            .putString(KEY_URI_ROLES, settings.rolesUriString)
            .putString(KEY_URI_LOCATIONS, settings.locationsUriString)
            .putString(KEY_URI_REGULAR_LIST, settings.regularListUriString)
            .putString(KEY_LAST_REGULAR_LIST_HEADER, settings.lastRegularListHeader)
            .putBoolean(KEY_CONDITIONAL_REGULAR_LIST_RELOAD_PENDING, settings.conditionalRegularListReloadPending)
            .apply()
    }

    // Apply current retention setting immediately and persist
    fun applyRetentionNow() {
        pruneHistoryOlderThan(days = settings.historyRetentionDays)
        saveHistory()
    }

    fun getHistoryWithin(days: Long): List<HistoryEntry> {
        val cutoff = Instant.now().minusSeconds(days * 24 * 3600).toEpochMilli()
        return history.filter { it.departureEpochMillis >= cutoff }
    }

    fun buildHistoryCsv(days: Long = settings.historyRetentionDays): String {
        val sb = StringBuilder()
        sb.append("Name,Role/Location,Sign-in,Sign-out\n")
        val rows = getHistoryWithin(days)
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault())
        rows.forEach { e ->
            val name = e.name.csvEscape()
            val role = e.roleOrLocation.csvEscape()
            val arrival = formatter.format(Instant.ofEpochMilli(e.arrivalEpochMillis))
            val departure = formatter.format(Instant.ofEpochMilli(e.departureEpochMillis))
            sb.append("$name,$role,$arrival,$departure\n")
        }
        return sb.toString()
    }

    /**
     * Reload all data lists from persisted last-picked URIs in settings. No-op if URIs are absent.
     */
    fun refreshAllFromPersistedUris() {
        if (!::appContext.isInitialized) return
        fun readCsvRaw(uriStr: String?): List<String> {
            if (uriStr.isNullOrBlank()) return emptyList()
            return try {
                val uri = Uri.parse(uriStr)
                appContext.contentResolver.openInputStream(uri)?.use { input ->
                    java.io.BufferedReader(java.io.InputStreamReader(input)).readLines()
                } ?: emptyList()
            } catch (_: Throwable) { emptyList() }
        }

        // Names: still only first column
        readCsvRaw(settings.namesUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val names = raw.map { it.split(',').firstOrNull()?.trim() ?: "" }.filter { it.isNotBlank() }
            if (names.isNotEmpty()) loadNames(names)
        }
        val splitter = Regex(
            
            
            """,(?=(?:[^"]*"[^"]*")*[^"]*$)"""
        )
        // Roles: column 1, row 2 down from rolesUriString
        readCsvRaw(settings.rolesUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val roles = mutableListOf<String>()
            raw.drop(1).forEach { row ->
                val firstCol = splitter.split(row, 2).firstOrNull()?.trim()?.trim('"') ?: ""
                if (firstCol.isNotEmpty()) roles.add(firstCol)
            }
            if (roles.isNotEmpty()) loadRoles(roles)
        }
        // Locations: column 1, row 2 down from locationsUriString
        readCsvRaw(settings.locationsUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val locs = mutableListOf<String>()
            raw.drop(1).forEach { row ->
                val firstCol = splitter.split(row, 2).firstOrNull()?.trim()?.trim('"') ?: ""
                if (firstCol.isNotEmpty()) locs.add(firstCol)
            }
            if (locs.isNotEmpty()) loadLocations(locs)
        }
        readCsvRaw(settings.regularListUriString).takeIf { it.isNotEmpty() }?.let { lines ->
            // Column 1 contains title (row 1) and members (rows 2+). Do not overwrite user-defined headerText.
            val splitter = Regex(
                
                
                """,(?=(?:[^"]*"[^"]*")*[^"]*$)"""
            )
            playTitle = lines.firstOrNull()?.let { first ->
                splitter.split(first).firstOrNull()?.trim()?.trim('"')?.take(30)
            } ?: ""
            val members = if (lines.size > 1) lines.drop(1) else emptyList()
            replaceRegularListMembersPreserveState(members)
        }
    }

    /**
     * Like refreshAllFromPersistedUris(), but if a one-time conditional reload is pending
     * (after the special reset code "######"), then only reload the Regular List if the
     * header (row 1, col 1) differs from the last uploaded header. Always refresh the
     * other databases (Names/Roles/Locations). The pending flag is cleared after running.
     */
    fun refreshAllFromPersistedUrisConditionalCast() {
        if (!::appContext.isInitialized) return
        fun readCsvRaw(uriStr: String?): List<String> {
            if (uriStr.isNullOrBlank()) return emptyList()
            return try {
                val uri = android.net.Uri.parse(uriStr)
                appContext.contentResolver.openInputStream(uri)?.use { input ->
                    java.io.BufferedReader(java.io.InputStreamReader(input)).readLines()
                } ?: emptyList()
            } catch (_: Throwable) { emptyList() }
        }

        // Always refresh Names/Roles/Locations
        readCsvRaw(settings.namesUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val names = raw.map { it.split(',').firstOrNull()?.trim() ?: "" }.filter { it.isNotBlank() }
            if (names.isNotEmpty()) loadNames(names)
        }
        val splitter = Regex(
            
            
            """,(?=(?:[^"]*"[^"]*")*[^"]*$)"""
        )
        readCsvRaw(settings.rolesUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val roles = mutableListOf<String>()
            raw.drop(1).forEach { row ->
                val firstCol = splitter.split(row, 2).firstOrNull()?.trim()?.trim('"') ?: ""
                if (firstCol.isNotEmpty()) roles.add(firstCol)
            }
            if (roles.isNotEmpty()) loadRoles(roles)
        }
        readCsvRaw(settings.locationsUriString).takeIf { it.isNotEmpty() }?.let { raw ->
            val locs = mutableListOf<String>()
            raw.drop(1).forEach { row ->
                val firstCol = splitter.split(row, 2).firstOrNull()?.trim()?.trim('"') ?: ""
                if (firstCol.isNotEmpty()) locs.add(firstCol)
            }
            if (locs.isNotEmpty()) loadLocations(locs)
        }

        if (settings.conditionalRegularListReloadPending) {
            val lines = readCsvRaw(settings.regularListUriString)
            if (lines.isNotEmpty()) {
                val newHeader = splitter.split(lines.first()).firstOrNull()?.trim()?.trim('"')?.take(30) ?: ""
                val lastHeader = settings.lastRegularListHeader ?: ""
                if (newHeader != lastHeader) {
                    playTitle = newHeader
                    val members = if (lines.size > 1) lines.drop(1) else emptyList()
                    replaceRegularListMembersPreserveState(members)
                    updateSettings { it.copy(lastRegularListHeader = newHeader) }
                }
            }
            // Clear pending flag regardless of outcome
            updateSettings { it.copy(conditionalRegularListReloadPending = false) }
        } else {
            // Fallback to normal behavior
            refreshAllFromPersistedUris()
        }
    }

    // Backward-compatible aliases removed to avoid deprecation warnings. If legacy callers exist,
    // consider re-introducing shim functions without deprecation or update call sites.

    /**
     * Schedule a WorkManager periodic job to run daily around 3:00 AM local time.
     */
    private fun scheduleDailyMaintenance(context: Context) {
        val workManager = WorkManager.getInstance(context)
        val uniqueName = "DailyMaintenanceWork"

        if (!settings.dailyJobEnabled) {
            workManager.cancelUniqueWork(uniqueName)
            return
        }

        // Compute initial delay until next 03:00 local time
        val now = java.time.ZonedDateTime.now()
        var nextRun = now.withHour(settings.dailyJobHour.coerceIn(0,23))
            .withMinute(settings.dailyJobMinute.coerceIn(0,59))
            .withSecond(0)
            .withNano(0)
        if (!nextRun.isAfter(now)) {
            nextRun = nextRun.plusDays(1)
        }
        val initialDelayMinutes = java.time.Duration.between(now, nextRun).toMinutes().coerceAtLeast(1)

        val constraints = androidx.work.Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val request = PeriodicWorkRequestBuilder<DailyMaintenanceWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setInitialDelay(initialDelayMinutes, TimeUnit.MINUTES)
            .build()

        workManager.enqueueUniquePeriodicWork(
            uniqueName,
            ExistingPeriodicWorkPolicy.REPLACE,
            request
        )
    }

    fun rescheduleDailyMaintenance() {
        if (!::appContext.isInitialized) return
        scheduleDailyMaintenance(appContext)
    }

    fun cancelDailyMaintenance() {
        if (!::appContext.isInitialized) return
        WorkManager.getInstance(appContext).cancelUniqueWork("DailyMaintenanceWork")
    }

    fun nextDailyRunTimeString(): String {
        val now = java.time.ZonedDateTime.now()
        var nextRun = now.withHour(settings.dailyJobHour.coerceIn(0,23))
            .withMinute(settings.dailyJobMinute.coerceIn(0,59))
            .withSecond(0)
            .withNano(0)
        if (!nextRun.isAfter(now)) nextRun = nextRun.plusDays(1)
        val fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(now.zone)
        return fmt.format(nextRun)
    }

    /**
     * Reset Regular List ("Cast") to empty and set runtime Play Title to the current Default Title.
     * Does not modify the Default Title itself. Also clears the persisted Regular List URI so the
     * Admin upload button appears in its default state next time.
     */
    fun resetRegularListAndUseDefaultTitle() {
        stageMembers.clear()
        stageActive.clear()
        stageTappedAt.clear()
        if (::appContext.isInitialized) {
            Storage.saveRegularListMembers(appContext, stageMembers)
            Storage.saveRegularListState(appContext, stageActive, stageTappedAt)
        }
        playTitle = settings.headerText
        // Keep the Regular List URI so the next auto refresh can conditionally reload from it
        updateSettings { it.copy(conditionalRegularListReloadPending = true) }
    }
}

private fun String.csvEscape(): String {
    val needsQuotes = this.contains(',') || this.contains('"') || this.contains('\n')
    return if (needsQuotes) {
        '"' + this.replace("\"", "\"\"") + '"'
    } else this
}
