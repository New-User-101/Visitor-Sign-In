package stu.gpt.signing.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


@Composable
fun PinPadDialog(
    title: String,
    onSubmit: (String) -> Unit,
    onCancel: () -> Unit,
    enterLabel: String = "Enter",
    cancelLabel: String = "Cancel"
) {
    Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            val pin = remember { mutableStateOf("") }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF2F2F2), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = if (pin.value.isEmpty()) "4-digit PIN?" else "#".repeat(pin.value.length),
                    fontSize = 25.sp
                )
            }
            Spacer(Modifier.height(12.dp))
            val digits = listOf(
                listOf("1","2","3"),
                listOf("4","5","6"),
                listOf("7","8","9"),
                listOf("←","0","C"),
            )
            digits.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    row.forEach { d ->
                        KeyButton(label = d, modifier = Modifier.weight(1f)) {
                            when (d) {
                                "C" -> pin.value = ""
                                "←" -> if (pin.value.isNotEmpty()) pin.value = pin.value.dropLast(1)
                                else -> if (pin.value.length < 4 && d[0].isDigit()) pin.value += d
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFFFDE691), RoundedCornerShape(8.dp))
                        .clickable { onCancel() }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(cancelLabel,fontSize = 25.sp, color = Color(0xFF000000), fontWeight = FontWeight.Bold) }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF12FA28), RoundedCornerShape(8.dp))
                        .clickable { if (pin.value.length == 4) onSubmit(pin.value) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(enterLabel,fontSize = 22.sp, color = Color(0xFF000000), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun KeyButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier // Number Pad Number Size
            .aspectRatio(1f)
            .background(Color(0xFFD9E1F2), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF000000), textAlign = TextAlign.Center)
    }
}
