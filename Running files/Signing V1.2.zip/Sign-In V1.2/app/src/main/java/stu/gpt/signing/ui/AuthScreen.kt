package stu.gpt.signing.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import stu.gpt.signing.data.Repository

@Composable
fun AdminAuthScreen(onSuccess: () -> Unit, onCancel: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.3f)
                .fillMaxHeight(0.5f)
        ) {
            PinPadDialog(
                title = "Enter Admin PIN",
                onSubmit = {
                    if (it == Repository.settings.pin) {
                        onSuccess()
                    } else {
                        // Handle incorrect PIN
                    }
                },
                onCancel = onCancel,
                enterLabel = "Login",
                cancelLabel = "Back"
            )
        }
    }
}
