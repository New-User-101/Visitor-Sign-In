package stu.gpt.signing.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.time.Instant

object Storage {
    private const val HISTORY_FILE = "history.json"
    private const val VISITORS_FILE = "visitors.json"
    private const val STAGE_FILE = "stage_state.json"
    private const val STAGE_MEMBERS_FILE = "stage_members.json"
    private const val REGULAR_LIST_STATE_FILE = "regular_list_state.json"
    private const val REGULAR_LIST_MEMBERS_FILE = "regular_list_members.json"

    fun loadHistory(context: Context): List<HistoryEntry> {
        return try {
            val file = File(context.filesDir, HISTORY_FILE)
            if (!file.exists()) return emptyList()
            val text = BufferedReader(FileReader(file)).use { it.readText() }
            val arr = JSONArray(text)
            val list = mutableListOf<HistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    HistoryEntry(
                        name = o.optString("name"),
                        roleOrLocation = o.optString("roleOrLocation"),
                        arrivalEpochMillis = o.optLong("arrivalEpochMillis"),
                        departureEpochMillis = o.optLong("departureEpochMillis", Instant.now().toEpochMilli())
                    )
                )
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveHistory(context: Context, items: List<HistoryEntry>) {
        try {
            val file = File(context.filesDir, HISTORY_FILE)
            val arr = JSONArray()
            items.forEach { e ->
                val o = JSONObject()
                o.put("name", e.name)
                o.put("roleOrLocation", e.roleOrLocation)
                o.put("arrivalEpochMillis", e.arrivalEpochMillis)
                o.put("departureEpochMillis", e.departureEpochMillis)
                arr.put(o)
            }
            FileWriter(file, false).use { fw -> fw.write(arr.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    fun loadVisitors(context: Context): List<VisitorEntry> {
        return try {
            val file = File(context.filesDir, VISITORS_FILE)
            if (!file.exists()) return emptyList()
            val text = BufferedReader(FileReader(file)).use { it.readText() }
            val arr = JSONArray(text)
            val list = mutableListOf<VisitorEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    VisitorEntry(
                        name = o.optString("name"),
                        roleOrLocation = o.optString("roleOrLocation"),
                        arrivalEpochMillis = o.optLong("arrivalEpochMillis", Instant.now().toEpochMilli())
                    )
                )
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveVisitors(context: Context, items: List<VisitorEntry>) {
        try {
            val file = File(context.filesDir, VISITORS_FILE)
            val arr = JSONArray()
            items.forEach { e ->
                val o = JSONObject()
                o.put("name", e.name)
                o.put("roleOrLocation", e.roleOrLocation)
                o.put("arrivalEpochMillis", e.arrivalEpochMillis)
                arr.put(o)
            }
            FileWriter(file, false).use { fw -> fw.write(arr.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    data class StageState(
        val active: Map<String, Long>,
        val tappedAt: Map<String, Long>
    )

    fun loadStageState(context: Context): StageState {
        return try {
            val file = File(context.filesDir, STAGE_FILE)
            if (!file.exists()) return StageState(emptyMap(), emptyMap())
            val text = BufferedReader(FileReader(file)).use { it.readText() }
            val obj = JSONObject(text)
            val activeObj = obj.optJSONObject("active") ?: JSONObject()
            val tappedObj = obj.optJSONObject("tappedAt") ?: JSONObject()
            val active = mutableMapOf<String, Long>()
            val tapped = mutableMapOf<String, Long>()
            activeObj.keys().forEach { k -> active[k] = activeObj.optLong(k, 0L) }
            tappedObj.keys().forEach { k -> tapped[k] = tappedObj.optLong(k, 0L) }
            StageState(active, tapped)
        } catch (_: Throwable) {
            StageState(emptyMap(), emptyMap())
        }
    }

    fun saveStageState(context: Context, active: Map<String, Long>, tappedAt: Map<String, Long>) {
        try {
            val file = File(context.filesDir, STAGE_FILE)
            val obj = JSONObject()
            val activeObj = JSONObject()
            active.forEach { (k, v) -> activeObj.put(k, v) }
            val tappedObj = JSONObject()
            tappedAt.forEach { (k, v) -> tappedObj.put(k, v) }
            obj.put("active", activeObj)
            obj.put("tappedAt", tappedObj)
            FileWriter(file, false).use { fw -> fw.write(obj.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    fun loadStageMembers(context: Context): List<String> {
        return try {
            val file = File(context.filesDir, STAGE_MEMBERS_FILE)
            if (!file.exists()) return emptyList()
            val text = BufferedReader(FileReader(file)).use { it.readText() }
            val arr = JSONArray(text)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val v = arr.optString(i)
                if (v.isNotBlank()) list.add(v)
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveStageMembers(context: Context, members: List<String>) {
        try {
            val file = File(context.filesDir, STAGE_MEMBERS_FILE)
            val arr = JSONArray()
            members.forEach { arr.put(it) }
            FileWriter(file, false).use { fw -> fw.write(arr.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    // RegularList versions with backward compatibility to Stage files
    fun loadRegularListState(context: Context): StageState {
        return try {
            val regFile = File(context.filesDir, REGULAR_LIST_STATE_FILE)
            if (regFile.exists()) {
                val text = BufferedReader(FileReader(regFile)).use { it.readText() }
                val obj = JSONObject(text)
                val activeObj = obj.optJSONObject("active") ?: JSONObject()
                val tappedObj = obj.optJSONObject("tappedAt") ?: JSONObject()
                val active = mutableMapOf<String, Long>()
                val tapped = mutableMapOf<String, Long>()
                activeObj.keys().forEach { k -> active[k] = activeObj.optLong(k, 0L) }
                tappedObj.keys().forEach { k -> tapped[k] = tappedObj.optLong(k, 0L) }
                StageState(active, tapped)
            } else {
                loadStageState(context)
            }
        } catch (_: Throwable) {
            StageState(emptyMap(), emptyMap())
        }
    }

    fun saveRegularListState(context: Context, active: Map<String, Long>, tappedAt: Map<String, Long>) {
        try {
            val file = File(context.filesDir, REGULAR_LIST_STATE_FILE)
            val obj = JSONObject()
            val activeObj = JSONObject()
            active.forEach { (k, v) -> activeObj.put(k, v) }
            val tappedObj = JSONObject()
            tappedAt.forEach { (k, v) -> tappedObj.put(k, v) }
            obj.put("active", activeObj)
            obj.put("tappedAt", tappedObj)
            FileWriter(file, false).use { fw -> fw.write(obj.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    fun loadRegularListMembers(context: Context): List<String> {
        return try {
            val regFile = File(context.filesDir, REGULAR_LIST_MEMBERS_FILE)
            val file = if (regFile.exists()) regFile else File(context.filesDir, STAGE_MEMBERS_FILE)
            if (!file.exists()) return emptyList()
            val text = BufferedReader(FileReader(file)).use { it.readText() }
            val arr = JSONArray(text)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val v = arr.optString(i)
                if (v.isNotBlank()) list.add(v)
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveRegularListMembers(context: Context, members: List<String>) {
        try {
            val file = File(context.filesDir, REGULAR_LIST_MEMBERS_FILE)
            val arr = JSONArray()
            members.forEach { arr.put(it) }
            FileWriter(file, false).use { fw -> fw.write(arr.toString()) }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }

    /**
     * Remove legacy Stage files if the RegularList files are present.
     * This is safe and idempotent.
     */
    fun removeLegacyStageFilesIfMigrated(context: Context) {
        try {
            val regState = File(context.filesDir, REGULAR_LIST_STATE_FILE)
            val regMembers = File(context.filesDir, REGULAR_LIST_MEMBERS_FILE)
            if (regState.exists()) {
                File(context.filesDir, STAGE_FILE).takeIf { it.exists() }?.delete()
            }
            if (regMembers.exists()) {
                File(context.filesDir, STAGE_MEMBERS_FILE).takeIf { it.exists() }?.delete()
            }
        } catch (_: Throwable) {
            // ignore for MVP
        }
    }
}

