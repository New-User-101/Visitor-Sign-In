package stu.gpt.signing.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import android.util.Log

    /**
     * Runs at ~3:00 AM daily (scheduled from Repository.initialize).
     * - Signs out all currently signed-in Visitors and Stage members
     * - Refreshes all databases from the last-picked document URIs (Names, Roles, Locations, Stage)
     * - Applies history retention and persists
     */
class DailyMaintenanceWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            Log.d("DailyMaintenanceWorker", "Starting daily maintenance job…")
            // Sign-out everyone currently signed-in (visitors + Regular List)
            Repository.signOutAllNow()
            Repository.regularListSignOutAllNow()

            // Refresh data from persisted URIs.
            // If a one-time conditional reload is pending (after ######),
            // only reload Regular List when the header changed; otherwise normal refresh.
            Repository.refreshAllFromPersistedUrisConditionalCast()

            // Apply retention and persist
            Repository.applyRetentionNow()

            Log.d("DailyMaintenanceWorker", "Daily maintenance job completed successfully.")
            Result.success()
        } catch (t: Throwable) {
            Log.e("DailyMaintenanceWorker", "Daily maintenance job failed: ${t.message}", t)
            Result.retry()
        }
    }
}
