package stu.gpt.signing.ui
/*
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.preference.isNotEmpty
import java.io.BufferedReader
import java.io.InputStreamReader
import stu.gpt.signing.data.Repository
import stu.gpt.signing.data.ThemeOption

// Which CSV we are picking
private enum class CsvKind { Names, Roles, Locations }

@Composable
fun AdminScreen(
    onSave: () -> Unit,
    onExitApp: () -> Unit,
    onExportHistory: () -> Unit,
) {
    val settings = Repository.settings
    var showPinChange by remember { mutableStateOf(false) }
    var headerText by remember { mutableStateOf(settings.headerText) }
    var selectedTheme by remember { mutableStateOf(settings.themeOption) }
    val context = LocalContext.current

    var pendingPick by remember { mutableStateOf<CsvKind?>(null) }

    // SAF picker for CSV/text files
    val csvPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            if (uri != null) {
                val lines = readCsvSimple(context, uri)
                if (lines.isNotEmpty()) {
                    when (pendingPick) {
                        CsvKind.Names -> Repository.loadNames(lines)
                        CsvKind.Roles -> Repository.loadRoles(lines)
                        CsvKind.Locations -> Repository.loadLocations(lines)
                        null -> {}
                    }
                }
            }
            pendingPick = null
        }
    )

    Surface(modifier = Modifier.fillMaxSize(), color = settings.primaryBgColor) {
        Column(modifier = Modifier.fillMaxSize().padding(30.dp)) {
            Text("Admin Area", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            // Change PIN
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { showPinChange = true },
                    modifier = Modifier
                ) { Text("Change PIN") }
                // Header text input (max 30 chars)
                TextField(
                    value = headerText,
                    onValueChange = { headerText = it.take(30) },
                    placeholder = { Text("Header (max 30 chars)") },
                    singleLine = true,
                    modifier = Modifier.weight(4f)
                )
            }

            Spacer(Modifier.height(10.dp))
            Text("Background Options", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ThemeOptionChip(
                    label = "",//Option 1
                    color = Color(0xff00b0f0),
                    selected = selectedTheme == ThemeOption.OPTION1,
                    modifier = Modifier.weight(1f)
                ) {
                    selectedTheme = ThemeOption.OPTION1
                }
                ThemeOptionChip(
                    label = "", //Option 2
                    color = Color(0xFffc6e0b4),
                    selected = selectedTheme == ThemeOption.OPTION2,
                    modifier = Modifier.weight(1f)
                ) {
                    selectedTheme = ThemeOption.OPTION2
                }
                ThemeOptionChip(
                    label = "",//Option 3
                    color = Color(0xfffdd76b),
                    selected = selectedTheme == ThemeOption.OPTION3,
                    modifier = Modifier.weight(1f)
                ) {
                    selectedTheme = ThemeOption.OPTION3
                }
                ThemeOptionChip(
                    label = "",//Option 4
                    color = Color(0xff48fe9f),
                    selected = selectedTheme == ThemeOption.OPTION4,
                    modifier = Modifier.weight(1f)
                ) {
                    selectedTheme = ThemeOption.OPTION4
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Upload CSVs", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
                CsvButton("Name.csv", modifier = Modifier.weight(1f)) {
                    pendingPick = CsvKind.Names
                    csvPicker.launch(
                        arrayOf(
                            "text/*",
                            "text/csv",
                            "application/csv",
                            "text/comma-separated-values"
                        )
                    )
                }
                CsvButton("Role.csv", modifier = Modifier.weight(1f)) {
                    pendingPick = CsvKind.Roles
                    csvPicker.launch(
                        arrayOf(
                            "text/*",
                            "text/csv",
                            "application/csv",
                            "text/comma-separated-values"
                        )
                    )
                }
                CsvButton("Location.csv", modifier = Modifier.weight(1f)) {
                    pendingPick = CsvKind.Locations
                    csvPicker.launch(
                        arrayOf(
                            "text/*",
                            "text/csv",
                            "application/csv",
                            "text/comma-separated-values"
                        )
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier // SAVE BUTTON
                        .weight(1f)
                        .background(Color(0xFF12FA28), RoundedCornerShape(8.dp))
                        .clickable {
                            Repository.updateSettings {
                                it.copy(
                                    headerText = headerText.take(30),
                                    themeOption = selectedTheme
                                )
                            }
                            onSave()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Save", color = Color(0xFF000000), fontWeight = FontWeight.Bold) }

                Box(
                    modifier = Modifier // EXIT APP BUTTON
                        .weight(1f)
                        .background(Color(0xffff6347), RoundedCornerShape(8.dp)) // Light red color
                        .clickable { onExitApp() }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Exit App", color = Color(0xff000000), fontWeight = FontWeight.Bold) }

                Box(
                    modifier = Modifier // EXPORT HISTORY BUTTON
                        .weight(1f)
                        .background(Color(0xfffffcc00), RoundedCornerShape(8.dp))
                        .clickable {
                            val ok = Repository.exportHistoryCsv()
                            if (ok) Repository.clearVisitorsOnExport()
                            onExportHistory()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Export History",
                        color = Color(0xFF000000),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showPinChange) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            PinPadDialog(
                title = "Enter New PIN",
                onSubmit = { pin ->
                    Repository.updateSettings { it.copy(pin = pin) }
                    showPinChange = false
                },
                onCancel = { showPinChange = false },
                enterLabel = "Enter",
                cancelLabel = "Cancel"
            )
        }
    }
}

@Composable
private fun ThemeOptionChip(
    label: String,
    color: Color,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .background(color, RoundedCornerShape(8.dp))
            .border(if (selected) 3.dp else 1.dp, Color.Black, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color(0xFF000000), fontWeight = FontWeight.Bold) }
}

@Composable
private fun CsvButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .background(Color(0xFF95F852), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color(0xFF000000), fontWeight = FontWeight.Bold) }
}
*/