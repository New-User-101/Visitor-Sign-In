package stu.gpt.signing

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import stu.gpt.signing.ui.AdminScreen
import stu.gpt.signing.ui.AdminAuthScreen
import stu.gpt.signing.ui.SignInScreen
import stu.gpt.signing.ui.theme.SigningTheme
import stu.gpt.signing.data.Repository
//import androidx.compose.foundation.layout.BoxWithConstraints
//import androidx.compose.ui.unit.dp
import android.content.pm.ActivityInfo

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize repository persistence & retention
        Repository.initialize(this)
        // Apply initial orientation based on current setting
        requestedOrientation = if (Repository.settings.isScreenFlipped) {
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        enableEdgeToEdge()
        setContent { AppRoot(onExit = { finish() }) }
    }

    override fun onResume() {
        super.onResume()
        // Re-apply orientation on resume to ensure emulator/devices keep the configured flip
        requestedOrientation = if (Repository.settings.isScreenFlipped) {
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }
}

private enum class Screen { SignIn, Admin }

@Composable
private fun AppRoot(onExit: () -> Unit) {
    SigningTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            val screen = remember { mutableStateOf(Screen.SignIn) }
            val showPin = remember { mutableStateOf(false) }

            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when (screen.value) {
                    Screen.SignIn -> SignInScreen(onAdminClick = { showPin.value = true })
                    Screen.Admin -> AdminScreen(
                        onSave = { screen.value = Screen.SignIn },
                        onExitApp = onExit,
                        onExportHistory = { /* handled in screen */ }
                    )
                }

                if (showPin.value) {
                    AdminAuthScreen(
                        onSuccess = {
                            showPin.value = false
                            screen.value = Screen.Admin
                        },
                        onCancel = { showPin.value = false }
                    )
                }
            }
        }
    }
}