package stu.gpt.signing.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
//import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
//import androidx.compose.foundation.layout.weight
import stu.gpt.signing.data.Repository
import stu.gpt.signing.data.VisitorEntry
// removed BoxWithConstraints and Dp imports
//import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.integerResource
import stu.gpt.signing.R
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
//import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
// Removed unused URI/decoder imports after standardizing placeholders


// Removed dynamic filename placeholder helper to keep UI labels consistent

@Composable
fun SignInScreen(
    onAdminClick: () -> Unit,
) {
    val settings by remember { derivedStateOf { Repository.settings } }
    val visitors by remember { derivedStateOf { Repository.visitors.toList() } }
    val stageMembers by remember { derivedStateOf { Repository.stageMembers.toList() } }
    val stageTappedAt by remember { derivedStateOf { Repository.stageTappedAt.toMap() } }
    val stageMembersOrdered by remember(stageMembers, stageTappedAt) {
        derivedStateOf {
            stageMembers.sortedWith(compareBy({ name ->
                // Untapped (red) first -> 0, Tapped (green) next -> 1
                if (stageTappedAt.containsKey(name)) 1 else 0
            }, { it.lowercase() }))
        }
    }
    var signOutTarget by remember { mutableStateOf<VisitorEntry?>(null) }
    var memberSignOutTarget by remember { mutableStateOf<String?>(null) }

    Surface(modifier = Modifier.fillMaxSize(), color = settings.primaryBgColor) {
        val outerFocusManager = LocalFocusManager.current
        val outerKeyboard = LocalSoftwareKeyboardController.current
        val closeMenusTrigger = remember { mutableIntStateOf(0) }
        // Flag to keep keyboard visible until Sign-In is pressed
        var keepKeyboardUntilSignIn by remember { mutableStateOf(false) }
        // Force-show the keyboard whenever the lock engages
        LaunchedEffect(keepKeyboardUntilSignIn) {
            if (keepKeyboardUntilSignIn) {
                outerKeyboard?.show()
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .pointerInput(keepKeyboardUntilSignIn) {
                    detectTapGestures(onTap = {
                        // Only hide keyboard/focus if not locked
                        if (!keepKeyboardUntilSignIn) {
                            outerFocusManager.clearFocus(force = true)
                            outerKeyboard?.hide()
                        }
                        closeMenusTrigger.intValue += 1
                    })
                }
        ) {

            val edgePadding = dimensionResource(R.dimen.edge_padding)

            // Single column layout: top wraps content, exactly one spacer row, then lists fill remaining space
            Column(modifier = Modifier.fillMaxSize().padding(edgePadding)) {
                // Top (wrap content height)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    TopSection(
                        onAdminClick = onAdminClick,
                        closeMenusTrigger = closeMenusTrigger.intValue,
                        keepKeyboardUntilSignIn = keepKeyboardUntilSignIn,
                        onRequestKeepKeyboard = { keepKeyboardUntilSignIn = true },
                        onRequestUnlockWithoutHide = { keepKeyboardUntilSignIn = false },
                        onRequestReleaseKeyboard = {
                            keepKeyboardUntilSignIn = false
                            outerKeyboard?.hide()
                            outerFocusManager.clearFocus(force = true)
                        }
                    )
                }
                // Exactly one small gap between instructions and headings
                Spacer(Modifier.height(4.dp))
                // Bottom fills remaining
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalAlignment = Alignment.Top
                ) {
                    // Left: Visitors
                    Column(
                        modifier = Modifier
                            .weight(0.6f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = settings.leftHeading,
                            fontSize = integerResource(R.integer.instruction_body_size).sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .widthIn(max = dimensionResource(R.dimen.max_list_width))
                                .border(
                                    BorderStroke(dimensionResource(R.dimen.border_stroke_width), settings.primaryBgColor),
                                    RoundedCornerShape(dimensionResource(R.dimen.corner_radius))
                                ),
                            color = Color.White,
                            shape = RoundedCornerShape(dimensionResource(R.dimen.corner_radius)),
                            shadowElevation = dimensionResource(R.dimen.card_elevation)
                        ) {
                            Box(modifier = Modifier.fillMaxSize().padding(edgePadding)) {
                                VisitorList(
                                    entries = visitors,
                                    selected = signOutTarget,
                                    onRowClick = { pending -> signOutTarget = pending }
                                )
                            }
                        }
                    }

                    Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))

                    // Right: Cast Members
                    Column(
                        modifier = Modifier
                            .weight(0.4f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = settings.rightHeading,
                            fontSize = integerResource(R.integer.instruction_body_size).sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(dimensionResource(R.dimen.internal_spacing)))
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .border(
                                    BorderStroke(dimensionResource(R.dimen.border_stroke_width), settings.primaryBgColor),
                                    RoundedCornerShape(dimensionResource(R.dimen.corner_radius))
                                ),
                            color = Color.White,
                            shape = RoundedCornerShape(dimensionResource(R.dimen.corner_radius)),
                            shadowElevation = dimensionResource(R.dimen.card_elevation)
                        ) {
                            Box(modifier = Modifier.fillMaxSize().padding(edgePadding)) {
                                MembersList(
                                    members = stageMembersOrdered,
                                    tappedAt = stageTappedAt,
                                    onTap = { name, isActive ->
                                        if (isActive) memberSignOutTarget = name else Repository.regularListToggle(name)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Sign-out confirm dialog
    if (signOutTarget != null) {
        AlertDialog(
            onDismissRequest = { signOutTarget = null },
            title = { Text("Sign-Out?", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { Text("Do you want to sign-out ${signOutTarget!!.name}?", fontSize = 22.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        Repository.signOut(signOutTarget!!)
                        signOutTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xff00b050))
                ) { Text("Yes", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                Button(
                    onClick = { signOutTarget = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xffff0000))
                ) { Text("No", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }
        )
    }

    // Cast Member sign-out confirm dialog
    if (memberSignOutTarget != null) {
        val nowText = remember {
            java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        }
        AlertDialog(
            onDismissRequest = { memberSignOutTarget = null },
            title = { Text("Sign-Out?", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            text = { Text("Sign-out ${memberSignOutTarget!!} at $nowText?", fontSize = 22.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        Repository.regularListToggle(memberSignOutTarget!!)
                        memberSignOutTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xff00b050))
                ) { Text("Yes", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                Button(
                    onClick = { memberSignOutTarget = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xffff0000))
                ) { Text("No", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }
        )
    }
}

@Composable
private fun TopSection(
    onAdminClick: () -> Unit,
    closeMenusTrigger: Int = 0,
    keepKeyboardUntilSignIn: Boolean,
    onRequestKeepKeyboard: () -> Unit,
    onRequestUnlockWithoutHide: () -> Unit,
    onRequestReleaseKeyboard: () -> Unit,
) {
    val settings by remember { derivedStateOf { Repository.settings } }

    var showMainHelp by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clickable { onAdminClick() }
                    .padding(
                        horizontal = dimensionResource(R.dimen.admin_button_padding_horizontal),
                        vertical = dimensionResource(R.dimen.admin_button_padding_vertical)
                    ),
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = Color(0xFF9C9C9C), fontWeight = FontWeight.Bold, fontSize = 36.sp) }
            Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                // Use Default Title only if Cast database (Regular List) is empty
                val effectiveTitle = if (Repository.stageMembers.isNotEmpty()) Repository.playTitle else settings.headerText
                Text(text = effectiveTitle, fontSize = integerResource(R.integer.header_text_size).sp, color = Color(0xFF000000), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, textDecoration = TextDecoration.Underline, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))
            // Help button mirrored to the cog (right side), white '?' in blue circular badge with white border
            Box(
                modifier = Modifier
                    .border(2.dp, Color.White, CircleShape)
                    .background(Color(0xFF0078D7), CircleShape)
                    .clickable { showMainHelp = true }
                    .padding(
                        horizontal = dimensionResource(R.dimen.admin_button_padding_horizontal),
                        vertical = dimensionResource(R.dimen.admin_button_padding_vertical)
                    ),
                contentAlignment = Alignment.Center
            ) { Text("?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 36.sp) }
        }
        if (showMainHelp) {
            AlertDialog(
                onDismissRequest = { showMainHelp = false },
                confirmButton = {
                    Button(onClick = { showMainHelp = false }) { Text("Back", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                },
                title = { Text("Help – Main", fontSize = 22.sp, fontWeight = FontWeight.Bold) },
                text = {
                    val noteFontSize = 18.sp
                    val noteLineHeight = 26.sp
                    val bulletSize = 24.sp
                    val mainNotes = listOf(
                        "Enter your Name, then pick a Role or a Location and tap Sign In.",
                        "Roles appear above the divider; Locations and others below.",
                        "To Sign-out: find and tap your name, then tap Yes to confirm sign-out."
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 460.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        mainNotes.forEach { line ->
                            Row(verticalAlignment = Alignment.Top) {
                                Text("\u2022", fontSize = bulletSize, color = Color(0xFF222222))
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = line,
                                    style = androidx.compose.ui.text.TextStyle(fontSize = noteFontSize, lineHeight = noteLineHeight),
                                    color = Color(0xFF222222)
                                )
                            }
                        }
                    }
                }
            )
        }
        Spacer(Modifier.height(dimensionResource(R.dimen.internal_spacing)))
        NameRoleLocationRow(
            closeMenusTrigger = closeMenusTrigger,
            keepKeyboardUntilSignIn = keepKeyboardUntilSignIn,
            onRequestKeepKeyboard = onRequestKeepKeyboard,
            onRequestUnlockWithoutHide = onRequestUnlockWithoutHide,
            onRequestReleaseKeyboard = onRequestReleaseKeyboard,
        )
        Spacer(Modifier.height(dimensionResource(R.dimen.internal_spacing)))
        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(top = dimensionResource(R.dimen.instruction_block_spacing))
        ) {
            // Line 1: Sign-In instruction
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("'General' Sign-In") }
                    append(": Please enter your name, role today OR working location.")
                },
                fontSize = integerResource(R.integer.instruction_body_size).sp,
                textAlign = TextAlign.Start,
                modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 10.dp) // Or .padding(10.dp) for all sides
            )
            // Line 2: Right column (dynamic) instruction
            Text(
                buildAnnotatedString {
                    val heading = Repository.settings.rightHeading
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("'") }
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(heading) }
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("' Sign-In") }
                    append(": Tap your name in the left-hand list below.")
                },
                fontSize = integerResource(R.integer.instruction_body_size).sp,
                textAlign = TextAlign.Start,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp) // Or .padding(10.dp) for all sides
            )
            Spacer(Modifier.height(dimensionResource(R.dimen.internal_spacing)))
            // Line 3: Cast Members instruction
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("To Sign-Out") }
                    append(": Tap your name below, then follow on-screen instructions")

                },
                fontSize = integerResource(R.integer.instruction_body_size).sp,
                textAlign = TextAlign.Start,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp) // Or .padding(10.dp) for all sides
            )
            // Reduce trailing space to keep headings closer and enlarge lists below
        }
    }
}

@Composable
private fun NameRoleLocationRow(
    closeMenusTrigger: Int = 0,
    keepKeyboardUntilSignIn: Boolean,
    onRequestKeepKeyboard: () -> Unit,
    onRequestUnlockWithoutHide: () -> Unit,
    onRequestReleaseKeyboard: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var roleExpanded by remember { mutableStateOf(false) }
    var locExpanded by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var nameExpanded by remember { mutableStateOf(false) }

    val density = LocalDensity.current
    var nameFieldWidth by remember { mutableStateOf(0.dp) }

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }

    // Validation and enablement rules
    val isNameValid by remember(name) {
        mutableStateOf(
            run {
                val parts = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                if (parts.size < 2) return@run false
                val first = parts[0].filter { it.isLetter() }
                val second = parts[1].filter { it.isLetter() }
                first.length >= 2 && second.length >= 3
            }
        )
    }
    val isFormValid by remember(name, role, location) {
        mutableStateOf(isNameValid && (role.isNotBlank() || location.isNotBlank()))
    }

    // Close all menus when the trigger changes (tap outside)
    LaunchedEffect(closeMenusTrigger) {
        nameExpanded = false
        roleExpanded = false
        locExpanded = false
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Name input with letters-only filter, white background, black text, rounded corners, and integrated suggestions
            Box(modifier = Modifier.weight(1f)) {
                TextField(
                    value = name,
                    onValueChange = { new ->
                        val raw = new.trim()
                        // Allow progressive entry of the special admin code (up to 6 '#') without filtering
                        if (raw.all { it == '#' } && raw.length <= 6) {
                            name = raw
                            nameExpanded = false
                            onRequestUnlockWithoutHide()
                        } else if (raw == "######") {
                            // Exact match handled above, but keep branch for clarity
                            name = raw
                            nameExpanded = false
                            onRequestUnlockWithoutHide()
                        } else {
                            // Allow only letters, spaces, hyphen, apostrophe
                            val filtered = new.filter { it.isLetter() || it == ' ' || it == '-' || it == '\'' }
                            // Auto-capitalize first letter and after separators (space, hyphen, apostrophe)
                            val capitalized = buildString(filtered.length) {
                                val separators = setOf(' ', '-', '\'')
                                var prevIsSep = true
                                for (ch in filtered) {
                                    if (prevIsSep && ch.isLetter()) {
                                        append(ch.uppercaseChar())
                                        prevIsSep = false
                                    } else {
                                        append(ch)
                                        prevIsSep = ch in separators
                                    }
                                }
                            }
                            name = capitalized
                            nameExpanded = true
                            if (name.isNotBlank()) onRequestKeepKeyboard() else onRequestUnlockWithoutHide()
                        }
                    },
                    placeholder = { Text("Enter Your Name Here",fontSize = integerResource(R.integer.field_text_size).sp, color = Color(0xff949494)) },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = integerResource(R.integer.field_text_size).sp),
                    shape = RoundedCornerShape(dimensionResource(R.dimen.corner_radius)),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        disabledContainerColor = Color.White,
                        errorContainerColor = Color.White,
                        focusedTextColor = Color(0xFF000000),
                        unfocusedTextColor = Color(0xFF000000),
                        disabledTextColor = Color(0xFF000000),
                        errorTextColor = Color(0xFF000000),
                        focusedPlaceholderColor = Color(0xFF9E9E9E),
                        unfocusedPlaceholderColor = Color(0xFF9E9E9E),
                        disabledPlaceholderColor = Color(0xFF9E9E9E),
                        errorPlaceholderColor = Color(0xFF9E9E9E),
                        cursorColor = Color(0xFF000000),
                        focusedIndicatorColor = Color(0xFF616161),
                        unfocusedIndicatorColor = Color(0xFF9E9E9E),
                        disabledIndicatorColor = Color(0xFFBDBDBD),
                        errorIndicatorColor = Color(0xFFFF3B30),
                    ),
                    modifier = Modifier
                        .fillMaxWidth()

                        .onGloballyPositioned { coords ->
                            nameFieldWidth = with(density) { coords.size.width.toDp() }
                        }
                        .focusRequester(focusRequester)
                        .onFocusChanged { fs ->
                            if (fs.isFocused) {
                                keyboardController?.show()
                                if (name.isNotBlank()) onRequestKeepKeyboard() else onRequestUnlockWithoutHide()
                            } else {
                                if (!keepKeyboardUntilSignIn) keyboardController?.hide()
                            }
                        },
                    // Keep keyboard active; avoid triggering sign-in from IME action
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.None),
                    keyboardActions = KeyboardActions()
                )

                val suggestions = if (name.isNotBlank()) Repository.names.filter { it.startsWith(name, ignoreCase = true) }.take(5) else emptyList()
                DropdownMenu(
                    expanded = nameExpanded && suggestions.isNotEmpty(),
                    onDismissRequest = { nameExpanded = false },
                    modifier = Modifier.width(nameFieldWidth)
                ) {
                    suggestions.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s, fontSize = integerResource(R.integer.field_text_size).sp) },
                            onClick = {
                                name = s
                                nameExpanded = false
                                // Keep keyboard if locked; otherwise dismiss
                                if (!keepKeyboardUntilSignIn) {
                                    keyboardController?.hide()
                                    focusManager.clearFocus(force = true)
                                } else {
                                    keyboardController?.show()
                                }
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))
            Button(
                onClick = {
                    val chosen = when {
                        role.isNotBlank() -> role
                        location.isNotBlank() -> location
                        else -> ""
                    }
                    val finalName = name.trim()
                    if (finalName == "######") {
                        // Special admin reset: clear Cast, reset upload button to default, set Play title to Default Title
                        Repository.resetRegularListAndUseDefaultTitle()
                        name = ""; role = ""; location = ""; roleExpanded = false; locExpanded = false
                        onRequestReleaseKeyboard()
                        return@Button
                    }
                    if (finalName.isNotEmpty()) {
                        Repository.signIn(finalName, chosen)
                        name = ""; role = ""; location = ""; roleExpanded = false; locExpanded = false
                        // Release keyboard lock on successful sign-in
                        onRequestReleaseKeyboard()
                    }
                },
                enabled = isFormValid || name.trim() == "######",
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xffaffe22),
                    disabledContainerColor = Color(0xff00b050),// start colour of Button
                    contentColor = Color(0xFF000000),
                    disabledContentColor = Color(0xFF616161)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(
                        horizontal = dimensionResource(R.dimen.button_padding_horizontal),
                        vertical = dimensionResource(R.dimen.button_padding_vertical)
                    ),
                contentPadding = PaddingValues(all = dimensionResource(R.dimen.dropdown_padding))
            ) {
                Text("Sign-In", fontSize = integerResource(R.integer.sign_in_button_text_size).sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Role dropdown
            Box(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(dimensionResource(R.dimen.corner_radius)))
                        .border(1.dp, Color.LightGray, RoundedCornerShape(dimensionResource(R.dimen.corner_radius)))
                        .clickable { roleExpanded = true }
                        .padding(dimensionResource(R.dimen.dropdown_padding))
                ) {
                    Text(
                        text = if (role.isNotEmpty()) role else run {
                            if (Repository.roles.isEmpty()) "Database not uploaded"
                            else "Choose Role"
                        },
                        color = if (role.isEmpty()) Color(0xff949494) else Color.Black,
                        fontSize = integerResource(R.integer.field_text_size).sp
                    )
                }
                DropdownMenu(expanded = roleExpanded, onDismissRequest = { roleExpanded = false }) {
                    Repository.roles.forEach { r ->
                        DropdownMenuItem(
                            text = { Text(r, fontSize = integerResource(R.integer.field_text_size).sp) },
                            onClick = {
                                // Keep keyboard if locked; otherwise dismiss
                                if (!keepKeyboardUntilSignIn) {
                                    keyboardController?.hide()
                                    focusManager.clearFocus(force = true)
                                } else {
                                    keyboardController?.show()
                                }
                                role = r
                                roleExpanded = false
                                location = ""
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(textDecoration = TextDecoration.Underline)) { append("OR") }
                },
                fontSize = integerResource(R.integer.or_text_size).sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(dimensionResource(R.dimen.internal_spacing)))
            // Location dropdown
            Box(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(dimensionResource(R.dimen.corner_radius)))
                        .border(1.dp, Color.LightGray, RoundedCornerShape(dimensionResource(R.dimen.corner_radius)))
                        .clickable { locExpanded = true }
                        .padding(dimensionResource(R.dimen.dropdown_padding))
                ) {
                    Text(
                        text = if (location.isNotEmpty()) location else run {
                            if (Repository.locations.isEmpty()) "Database not uploaded"
                            else "Choose Location"
                        },
                        color = if (location.isEmpty()) Color(0xff949494) else Color.Black,
                        fontSize = integerResource(R.integer.field_text_size).sp
                    )
                }
                DropdownMenu(expanded = locExpanded, onDismissRequest = { locExpanded = false }) {
                    Repository.locations.forEach { l ->
                        DropdownMenuItem(
                            text = { Text(l, fontSize = integerResource(R.integer.field_text_size).sp) },
                            onClick = {
                                // Keep keyboard if locked; otherwise dismiss
                                if (!keepKeyboardUntilSignIn) {
                                    keyboardController?.hide()
                                    focusManager.clearFocus(force = true)
                                } else {
                                    keyboardController?.show()
                                }
                                location = l
                                locExpanded = false
                                role = ""
                            }
                        )
                    }
                }
            }
        }
        // Predictive suggestions are integrated into the Name field dropdown above
    }
}

@Composable
private fun VisitorList(entries: List<VisitorEntry>, selected: VisitorEntry?, onRowClick: (VisitorEntry) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.list_row_spacing))
    ) {
        itemsIndexed(entries) { idx, e ->
            val interactionSource = remember { MutableInteractionSource() }
            val pressed by interactionSource.collectIsPressedAsState()
            val isSelected = selected == e

            // Determine grouping: Roles above, non-roles (locations/others) below
            val isRole = Repository.roles.any { it.equals(e.roleOrLocation, ignoreCase = true) }
            val isLowerGroup = !isRole
            // Background color animation
            // - Lower group (locations/others): highlight with 0xffe4ffd1
            // - Roles group: keep existing color
            val baseColor = if (isLowerGroup) Color(0xffe4ffd1) else Color(0xffaffe22)
            val rowBg by animateColorAsState(
                when {
                    isSelected -> baseColor.copy(alpha = 0.9f)
                    pressed -> baseColor.copy(alpha = 0.85f)
                    else -> baseColor.copy(alpha = 0.8f)
                },
                label = "rowBg"
            )

            // Insert a clear group divider at the transition from Roles -> lower group
            if (idx > 0) {
                val prev = entries[idx - 1]
                val prevIsRole = Repository.roles.any { it.equals(prev.roleOrLocation, ignoreCase = true) }
                if (prevIsRole && isLowerGroup) {
                    HorizontalDivider(
                        Modifier.fillMaxWidth(),
                        thickness = DividerDefaults.Thickness * 2f,
                        color = Repository.settings.primaryBgColor
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(dimensionResource(R.dimen.row_corner_radius)))
                    .background(rowBg)
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null // Use default M3 ripple
                    ) { onRowClick(e) }
                    .padding(vertical = dimensionResource(R.dimen.list_row_vertical_padding)),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(e.name, modifier = Modifier.weight(0.4f).padding(start = 5.dp), fontSize = integerResource(R.integer.list_row_size).sp)
                Text(e.roleOrLocation, modifier = Modifier.weight(0.4f).padding(start = 30.dp), fontSize = integerResource(R.integer.list_row_size).sp)
                Text(timeOf(e.arrivalEpochMillis), modifier = Modifier.weight(0.2f).padding(start = 25.dp), fontSize = integerResource(R.integer.list_row_size).sp)
            }
            HorizontalDivider(
                Modifier,
                DividerDefaults.Thickness,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
            )
        }
    }
}

private fun timeOf(epochMillis: Long): String {
    // Force 24-hour time format
    return java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(epochMillis))
}

@Composable
private fun MembersList(
    members: List<String>,
    tappedAt: Map<String, Long>,
    onTap: (String, Boolean) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.list_row_spacing))
    ) {
        items(members) { name ->
            val tappedTime = tappedAt[name]
            val isActive = tappedTime != null
            val bgColor = if (!isActive) Color(0xFFFFD1D1).copy(alpha = 0.7f) else Color(0xffaffe22).copy(alpha = 0.7f)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(dimensionResource(R.dimen.row_corner_radius)))
                    .background(bgColor)
                    .clickable { onTap(name, isActive) }
                    .padding(vertical = dimensionResource(R.dimen.list_row_vertical_padding)),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    name,
                    fontSize = integerResource(R.integer.list_row_size).sp,
                    modifier = Modifier
                        .weight(0.7f)
                        .padding(start = 16.dp)
                )
                val timeText = tappedTime?.let { epoch ->
                    java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(epoch))
                } ?: ""
                Text(
                    timeText,
                    fontSize = integerResource(R.integer.list_row_size).sp,
                    textAlign = TextAlign.End,
                    modifier = Modifier
                        .weight(0.3f)
                        .padding(end = 16.dp)
                )
            }
            HorizontalDivider(
                Modifier,
                DividerDefaults.Thickness,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
            )
        }
    }
}
