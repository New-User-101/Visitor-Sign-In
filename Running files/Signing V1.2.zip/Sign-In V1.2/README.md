# Signing-In App – User Guide

This guide explains how to use the app. It is split into two parts:
- Main Screen (for daily sign-ins)
- Admin Screen (for configuration and maintenance)

---

## Main Screen

- **[Open Admin]**
  - Tap the cog (⚙) in the top-left to open the Admin Screen.
  
- **[Title at top]**
  - Shows the Play Title (from the RH Side CSV) when the Cast database has members.
  - If the Cast database is empty, it shows the Default Title from Admin settings.

- **[Signing In]**
  - Enter your name in the Name box.
  - Choose either a Role or a Location (Only one).
  - Press Sign In to add the record to the live list.
  - If a name is not found in Members, it is recorded as a Guest.

- **[Sorting & Grouping]**
  - The live list is grouped with Roles first (above the divider) and non-Roles (Locations) below the divider.
  - Within each group, entries are sorted alphabetically by name.


---

## Admin Screen

- **[Top Bar Title]**
  - Displays “Admin Area – + Play Title if Cast has members; otherwise uses Default Title.

- **[Headings]**
  - Default Title (max 35 characters)
  - Left-Hand Heading (max 30 characters)
  - Right-Hand Heading (max 15 characters)

- **[Background Options]**
  - Choose one of the color chips.

- **[Auto Sign-out & Refresh]**
  - Enable or disable the daily maintenance job.
  - Set the 24-hour time for daily refresh.
  - The daily job will:
    - Sign out all current visitors and Regular List entries.
    - Reload CSVs from last-picked files.
    - Apply retention and persist.

- **[Data Management]**
  - Upload buttons (colors turn green when data is loaded):
    - Members – CSV with names in column 1, any header row is allowed.
    - Roles – CSV with roles in column 1, starting from row 2.
    - Locations – CSV with locations in column 1, starting from row 2.
    - RH Side (Cast) – CSV with:
      - Row 1, Column 1: Play Title.
      - Rows 2+, Column 1: Member names.
  - Refresh All
    - If all files are known, reloads them immediately.
    - If some are missing, prompts for them in order: Members → Roles → Locations → RH Side.

- **[Persistence & Startup]**
  - The app remembers your last-picked files (with read permission).
  - On startup, it automatically reloads Members, Roles, Locations, and RH Side.

- **[Retention]**
  - Set “Keep Sign-Out Records for this many days”.
  - On Save or daily maintenance, older records are pruned.

- **[Export History]**
  - Exports a CSV of sign-in history.
  - The export filename is prefixed with the date (e.g., `2025-10-06_History.csv`).

- **[Administration Notes]**
  - CSV is required for Members, Roles, Locations, and RH Side.
  - Button labels are taken from file names (Members/Roles/Locations should reside in `Documents/Sign-In Data`).
  - The RH Side (Cast) file can be in Downloads.
  - Exported history file is dated.
  - If “Keep Sign-Out Records” is set to 1, the database is cleared during maintenance.

---

## CSV Formats

- **Members.csv**
  - Column 1: Member names (header optional).

- **Roles.csv**
  - Column 1: Roles (row 2 and below). Title on Row 1/Column 1.

- **Locations.csv**
  - Column 1: Locations (row 2 and below).Title on Row 1/Column 1.

---

- **[Special Reset Code]**
  - Typing `######` into the Name box and pressing Sign In will:
    - Clear the Cast (RH Side) database.
    - Reset the RH Side upload button to its default label.
    - Set the Play Title to the Default Title.

## Tips

- For CSVs with commas inside values, quote the cell (e.g., "Stage, Left").
- Long file names are shortened on buttons; hover or re-upload to see the full name.
- If a CSV fails to load, use Refresh All to re-prompt for files.
